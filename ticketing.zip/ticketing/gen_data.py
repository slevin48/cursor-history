# %%

import pandas as pd

data = {
    'ticket_id': range(1, 11),
    'language': ['English', 'Spanish', 'French', 'English', 'Spanish', 'French', 'English', 'Spanish', 'French', 'English'],
    'reported_criticality': ['Low', 'High', 'Medium', 'High', 'Low', 'Medium', 'High', 'Medium', 'Low', 'High'],
    'content': [
        'Cannot access email account.',
        'No puedo imprimir desde mi computadora.',
        'Impossible de se connecter au réseau Wi-Fi.',
        'System crash when opening application.',
        'La pantalla está congelada y no responde.',
        'Le clavier ne fonctionne pas correctement.',
        'Error message displays on startup.',
        'La conexión a Internet es muy lenta.',
        'Le système ne reconnaît pas le périphérique USB.',
        'Files are missing from shared drive.'
    ]
}

df = pd.DataFrame(data)
df.to_csv('helpdesk_tickets.csv', index=False)

# %%
