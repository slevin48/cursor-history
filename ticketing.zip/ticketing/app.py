import pandas as pd
import openai
import os
from dotenv import load_dotenv

load_dotenv()

openai.api_key = os.getenv('OPENAI_API_KEY')

# Load the dataset
df = pd.read_csv('helpdesk_tickets.csv')

def chat(system_prompt, user_prompt, max_tokens=150):
    response = openai.chat.completions.create(
        model='gpt-4o-mini',
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        max_tokens=max_tokens,
        temperature=0
    )
    return response.choices[0].message.content.strip()

# Define helper functions
def classify_ticket(content):
    prompt = f"""
    You are a helpdesk manager. Classify the following ticket into one of the categories:
    - Access Issue
    - Hardware Problem
    - Software Error
    - Network Issue
    - Other

    Ticket Content:
    \"\"\"
    {content}
    \"\"\"

    Respond with the category name.
    """
    category = chat(prompt, 'gpt-4o-mini', 10)
    return category

def translate_ticket(content, language):
    if language == 'English':
        return content
    else:
        prompt = f"Translate the following {language} text to English:\n\n\"\"\"\n{content}\n\"\"\""
        translation = chat(prompt, 'gpt-4o-mini', 150)
        return translation

def detect_outlier(content, reported_criticality):
    prompt = f"""
    You are a helpdesk manager. Analyze the following ticket and determine the actual criticality level (Low, Medium, High):

    \"\"\"
    {content}
    \"\"\"

    The reported criticality is {reported_criticality}.

    Does the actual criticality match the reported criticality? Respond with 'Yes' or 'No' and a brief explanation.
    """
    analysis = chat(prompt, 'gpt-4o-mini', 60)
    return analysis

def write_email_summary(ticket_id, category, criticality, content):
    prompt = f"""
    Compose a brief email to the IT team summarizing the following ticket:

    Ticket ID: {ticket_id}
    Category: {category}
    Criticality: {criticality}
    Content: {content}

    The email should include the ticket ID, category, criticality, and a summary of the issue. Keep it concise and professional.
    """
    email = chat(prompt, 'gpt-4o-mini', 150)
    return email

# Process tickets
for index, row in df.iterrows():
    ticket_id = row['ticket_id']
    language = row['language']
    reported_criticality = row['reported_criticality']
    content = row['content']
    
    # Translate Ticket
    translated_content = translate_ticket(content, language)
    
    # Classify Ticket
    category = classify_ticket(translated_content)
    
    # Detect Outlier
    outlier_analysis = detect_outlier(translated_content, reported_criticality)
    
    # Write Email Summary
    email_summary = write_email_summary(ticket_id, category, reported_criticality, translated_content)
    
    # Output Results
    print(f"Ticket ID: {ticket_id}")
    print(f"Category: {category}")
    print(f"Outlier Analysis: {outlier_analysis}")
    print(f"Email Summary:\n{email_summary}")
    print("-" * 50)
